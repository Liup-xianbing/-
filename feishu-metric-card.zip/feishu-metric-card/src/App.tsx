import React, { useState, useEffect, useCallback } from 'react';
import './styles.css';

// 飞书 bitable 全局对象类型声明
declare global {
  interface Window {
    bitable?: {
      bridge: {
        getTableData: () => Promise<any>;
        getTableMeta: () => Promise<any>;
        getConfig: () => Promise<any>;
        setConfig: (config: any) => Promise<any>;
        onConfigChange: (callback: (config: any) => void) => void;
      };
    };
  }
}

interface Config {
  metricName: string;
  numeratorField: string;
  denominatorField: string;
  format: 'number' | 'percent' | 'currency';
  decimals: number;
  prefix: string;
  suffix: string;
}

interface TableRecord {
  [fieldId: string]: any;
}

interface TableField {
  id: string;
  name: string;
  type: string;
}

const DEFAULT_CONFIG: Config = {
  metricName: '平均单价',
  numeratorField: '',
  denominatorField: '',
  format: 'currency',
  decimals: 2,
  prefix: '¥',
  suffix: '',
};

const App: React.FC = () => {
  const [isConfiguring, setIsConfiguring] = useState(false);
  const [config, setConfig] = useState<Config>(DEFAULT_CONFIG);
  const [tableData, setTableData] = useState<TableRecord[]>([]);
  const [tableFields, setTableFields] = useState<TableField[]>([]);
  const [calculatedValue, setCalculatedValue] = useState<number | null>(null);

  // 获取表格数据
  const fetchTableData = useCallback(async () => {
    if (!window.bitable) {
      console.log('飞书环境未加载，使用演示数据');
      return;
    }
    try {
      const data = await window.bitable.bridge.getTableData();
      const meta = await window.bitable.bridge.getTableMeta();
      setTableData(data?.records || []);
      
      // 提取数字类型的字段
      const numberFields = meta?.fields?.filter(
        (field: TableField) => ['Number', 'Currency', 'Formula'].includes(field.type)
      ) || [];
      setTableFields(numberFields);
    } catch (err) {
      console.error('获取表格数据失败:', err);
    }
  }, []);

  // 获取配置
  const fetchConfig = useCallback(async () => {
    if (!window.bitable) return;
    try {
      const savedConfig = await window.bitable.bridge.getConfig();
      if (savedConfig && Object.keys(savedConfig).length > 0) {
        setConfig(prev => ({ ...DEFAULT_CONFIG, ...savedConfig }));
      }
    } catch (err) {
      console.error('获取配置失败:', err);
    }
  }, []);

  // 初始化
  useEffect(() => {
    fetchConfig();
    fetchTableData();

    if (window.bitable) {
      window.bitable.bridge.onConfigChange((newConfig: any) => {
        if (newConfig && Object.keys(newConfig).length > 0) {
          setConfig(prev => ({ ...DEFAULT_CONFIG, ...newConfig }));
        }
      });
    }
  }, [fetchConfig, fetchTableData]);

  // 计算指标值
  useEffect(() => {
    if (!config.numeratorField || !config.denominatorField || tableData.length === 0) {
      setCalculatedValue(null);
      return;
    }

    let numeratorSum = 0;
    let denominatorSum = 0;
    let validRecords = 0;

    tableData.forEach(record => {
      const numValue = parseFloat(record[config.numeratorField]);
      const denValue = parseFloat(record[config.denominatorField]);
      
      if (!isNaN(numValue) && !isNaN(denValue)) {
        numeratorSum += numValue;
        denominatorSum += denValue;
        validRecords++;
      }
    });

    if (validRecords === 0 || denominatorSum === 0) {
      setCalculatedValue(null);
    } else {
      setCalculatedValue(numeratorSum / denominatorSum);
    }
  }, [config, tableData]);

  // 格式化数值
  const formatValue = (value: number | null): string => {
    if (value === null || isNaN(value)) return '--';

    let displayValue = value;
    
    switch (config.format) {
      case 'percent':
        displayValue = value * 100;
        break;
      case 'currency':
      case 'number':
      default:
        displayValue = value;
    }

    const formattedNumber = displayValue.toFixed(config.decimals)
      .replace(/\B(?=(\d{3})+(?!\d))/g, ',');

    return `${config.prefix}${formattedNumber}${config.suffix}`;
  };

  // 保存配置
  const handleSaveConfig = async () => {
    if (!window.bitable) {
      console.log('演示模式：配置已保存到本地');
      setIsConfiguring(false);
      return;
    }
    try {
      await window.bitable.bridge.setConfig(config);
      setIsConfiguring(false);
    } catch (err) {
      console.error('保存配置失败:', err);
      alert('保存配置失败，请重试');
    }
  };

  // 获取字段名称
  const getFieldName = (fieldId: string): string => {
    const field = tableFields.find(f => f.id === fieldId);
    return field?.name || fieldId;
  };

  // 配置界面
  if (isConfiguring) {
    return (
      <div className="config-panel">
        <h3>配置自定义指标</h3>
        
        <div className="form-group">
          <label>指标名称</label>
          <input
            type="text"
            value={config.metricName}
            onChange={(e) => setConfig({ ...config, metricName: e.target.value })}
            placeholder="例如：平均单价"
          />
        </div>

        <div className="form-group">
          <label>分子字段（求和）</label>
          <select
            value={config.numeratorField}
            onChange={(e) => setConfig({ ...config, numeratorField: e.target.value })}
          >
            <option value="">请选择字段</option>
            {tableFields.map((field) => (
              <option key={field.id} value={field.id}>
                {field.name}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>分母字段（求和）</label>
          <select
            value={config.denominatorField}
            onChange={(e) => setConfig({ ...config, denominatorField: e.target.value })}
          >
            <option value="">请选择字段</option>
            {tableFields.map((field) => (
              <option key={field.id} value={field.id}>
                {field.name}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>数值格式</label>
          <select
            value={config.format}
            onChange={(e) => {
              const format = e.target.value as Config['format'];
              const newConfig: Config = { ...config, format };
              if (format === 'percent') {
                newConfig.suffix = '%';
                newConfig.prefix = '';
              } else if (format === 'currency') {
                newConfig.prefix = '¥';
                newConfig.suffix = '';
              } else {
                newConfig.prefix = '';
                newConfig.suffix = '';
              }
              setConfig(newConfig);
            }}
          >
            <option value="number">数值</option>
            <option value="percent">百分比</option>
            <option value="currency">货币</option>
          </select>
        </div>

        <div className="form-row">
          <div className="form-group small">
            <label>前缀</label>
            <input
              type="text"
              value={config.prefix}
              onChange={(e) => setConfig({ ...config, prefix: e.target.value })}
              disabled={config.format === 'percent'}
              placeholder="¥"
            />
          </div>
          <div className="form-group small">
            <label>后缀</label>
            <input
              type="text"
              value={config.suffix}
              onChange={(e) => setConfig({ ...config, suffix: e.target.value })}
              disabled={config.format === 'percent'}
              placeholder=""
            />
          </div>
          <div className="form-group small">
            <label>小数位</label>
            <input
              type="number"
              min={0}
              max={10}
              value={config.decimals}
              onChange={(e) => {
                const value = parseInt(e.target.value);
                setConfig({ ...config, decimals: isNaN(value) ? 0 : value });
              }}
            />
          </div>
        </div>

        <div className="formula-preview">
          <label>计算公式</label>
          <div className="formula">
            {config.numeratorField && config.denominatorField 
              ? `SUM(${getFieldName(config.numeratorField)}) ÷ SUM(${getFieldName(config.denominatorField)})`
              : '请先选择分子和分母字段'
            }
          </div>
        </div>

        <button className="save-btn" onClick={handleSaveConfig}>
          保存配置
        </button>
      </div>
    );
  }

  // 展示界面
  return (
    <div className="metric-card">
      <div className="metric-header">
        <span className="metric-title">{config.metricName || '自定义指标'}</span>
        <button 
          className="config-btn" 
          onClick={() => setIsConfiguring(true)} 
          title="配置"
          type="button"
        >
          <svg viewBox="0 0 24 24" width="16" height="16">
            <path 
              fill="currentColor" 
              d="M12 15.5A3.5 3.5 0 0 1 8.5 12 3.5 3.5 0 0 1 12 8.5a3.5 3.5 0 0 1 3.5 3.5 3.5 3.5 0 0 1-3.5 3.5m7.43-2.53c.04-.32.07-.66.07-1s-.03-.68-.07-1l2.11-1.63c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65A.488.488 0 0 0 14 2h-4c-.25 0-.46.18-.5.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.63c-.04.32-.07.66-.07 1s.03.68.07 1l-2.11 1.63c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.04.24.25.42.5.42h4c.25 0 .46-.18.5-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.63z"
            />
          </svg>
        </button>
      </div>
      <div className="metric-value">
        {formatValue(calculatedValue)}
      </div>
      {config.numeratorField && config.denominatorField && (
        <div className="metric-formula">
          {`${getFieldName(config.numeratorField)} ÷ ${getFieldName(config.denominatorField)}`}
        </div>
      )}
    </div>
  );
};

export default App;
